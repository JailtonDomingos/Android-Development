package com.projetc.domingos.militaryarms;

import android.preference.EditTextPreference;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

//public static usuario = "JAILTON";
//public static senha = "123";


public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        Button button4 = (Button) findViewById(R.id.button4);
        button4.setOnClickListener( new View.OnClickListener()){
           // @Override
            public void onClick(View activity_main) {

                EditText username = (EditText)findViewById(R.id.editText);
                EditText password = (EditText)findViewById(R.id.editText2);

                public void login (View view){
                    if(username.getText().toString().equals("JAILTON") && password.getText() == "123"){
                        EditText textView3 = (EditText) setVisible(true);
                        EditText textView3 = (EditText) "Senha Valida!";
                    }else{
                        EditText textView3 = (EditText) setVisible(true);
                        EditText textView3 = (EditText) "Senha Invalida!";
                    }
                }

            }

        }

    }

    //getString(R.string.app_name);

}
